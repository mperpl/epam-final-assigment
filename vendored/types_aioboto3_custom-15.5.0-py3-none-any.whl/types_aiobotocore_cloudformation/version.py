"""
Source of truth for version.

Copyright 2026 Vlad Emelianov
"""

__version__ = "15.5.0"
